var quotes= 
getElementByIndexRandom(array[, index]){
 if(index==null){
 var rand = array[Math.floor(Math.random() * array.length)];
}else{
 	return array[index];
 }
}

getQuotesFromJSON(){
return quotes
}

getQuoteFromJSON(){
	return quotes.json() 
}

seed(cb){

} 

getQuotesFromDB(cb){

}

getQuoteFromDB(){

}