$("body").click(function () { $.get("/api/quote", function (data, status){
	var M= math.random()* 360;
	var N = "hsl("+ M +",55%, 80%)";
	$("body").css("background", N);
    document.getElementById("quote").innerText=data.text; 
   document.getElementById("author").innerText = data.author; }) }); 
}