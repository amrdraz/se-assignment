var app = require("./app");
app.listen(3000,fuction()){
	console.log(" your server is conected on localhost 3000");
}