
var express = require('express')
var http = require('http');
var app= express();
var qoutes = require('./qoutes.js');
var fs = require('fs');
var mongo = require('mongodb');
var bP = require('body-parser');
var db = require('./db.js');
app.use(express.static(path.join(__dirname,'public')));
app.set('views', path.join(__dirname,'public'));

app.use (function(req,res,next)){
    req.db = db;
    next();
}
db.connect(function(db)){
    qoutes.seed(function(err,done))
    if(done==true){
        console.log("Insertion is done");
    }else
    {
        throw err;
    }
}

app.get('/api/qoutes', function(req. res)){
    var result = qoutes.getQuotesFromDB(function(err,qoutes))
    res.send(qoutes);
}

qpp.get('/api/qoutes', function(req, res)){
    var result = qoutes.getQuoteFromDB(function(err,qoute))
    res.send(qoute);
}

app.get('', function(req, res){

    res.writeHeader(404,{'Content-type':'text/html'});
    res.write("404 page not found");
}
app.get('/', function (req, res) {
  res.render(__dirname + '/index.html');
});


app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});
module.exports=app;

