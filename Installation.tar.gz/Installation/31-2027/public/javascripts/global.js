// Userlist data array for filling in info box
//var userListData = [];

// DOM Ready =============================================================
/*$(document).ready(function() {
    
    console.log("Ready");

});*/

// Functions =============================================================
//src='http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js'
//script(src='/javascripts/global.js') 


function getQuotesFromJSON(){
    var fileData = []; 
    fileData = $.getJSON('quotes.json');  
    seed(fileData);
}












/*function seed(cb) {
    // seeded is true when quotes are added to the database
   // seeded is false when nothing is added to the db
       // MongoClient mongo = new MongoClient("localhost", 3000);
        var MongoClient = require('mongodb').MongoClient;
        var a = MongoClient.getDB("mydb");
        var collection = a.getCollection("users");
        var o = [];
        o = JSON.parse(cb);
        collection.insert(o);
}*/

/*function seed(cb){
   var MongoClient = require('mongodb').MongoClient, Server = require('mongodb').Server;
   var mongoClient = new MongoClient(new Server('localhost', 3000));
   mongoClient.open(function(err, mongoClient) {
   var db1 = mongoClient.db("mydb");
   testing = "connecting";
   var collection = db1.getCollection("users");
        var o = [];
        o = JSON.parse(cb);
        collection.insert(o);

   mongoClient.close();
});
}*/



