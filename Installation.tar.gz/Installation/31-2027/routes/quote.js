var express = require('express');
var router = express.Router();
var fs  = require('fs');
//script(src='http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js')

/* GET users listing.
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
}); */

/*function getQuotesFromJSON(){
    var fileData = []; 
    fileData = $.getJSON('quotes.json');  
    function seed(fileData);
}*/

/*function seed(cb) {
    // seeded is true when quotes are added to the database
   // seeded is false when nothing is added to the db
        MongoClient mongo = new MongoClient("localhost", 3000);
        DB db = mongo.getDB("mydb");
        DBCollection collection = db.getCollection("users");
        DBObject o = (DBObject) JSON.parse(cb);
        collection.insert(o);
})*/


router.get('/quotelists', function (req, res) {
   fs.readFile("quotes.json", function (err, data) {
       res.send(data);    
   });
})

/*router.get('/quotelist', function(req, res, next) {
  res.sendFile(__dirname + './views/db.js');
});*/

router.get('/quotelist', function(req, res, next) {
  res.sendFile(__dirname + '/views/index.html');
});



module.exports = router;
