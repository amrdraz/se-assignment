var express = require('express');
var db = require('./db.js');
var app = express();

app.use(express.static('public'));


app.get('/api/post', function(req, res, next) {
 var count = db.db().collection('post').count();
 var rand = function(){return Math.floor( Math.random() * count )}
 res.send(db.db().collection('post').find().limit(-1).skip(rand()).next());
                                             });

db.connect(function(err) {
    console.log('connected to db');
    db.seed(function () {
        console.log('seeded db');
        app.listen(8080, function() {
            console.log('Example app listening on port 8080!');
        });
    });
});
module.exports = app;
